/*
 * calendario.c
 *
 *  Created on: 02/02/2012
 *      Author: cuki
 */
#include <18F452.h>

#fuses hs
#use delay (clock = 8MHz, RESTART_WDT)
#use i2c (master,scl=pin_c3,sda=pin_c4,force_hw,fast = 100000)

#include "lcd_8b.c"
#include "i2c.h"
#include <stdlib.h>

#define _SECONDS    0x00
#define _MINUTES    0x01
#define _HOURS    0x02
#define _DAY      0x03
#define _DATE    0x04
#define _MONTH    0x05
#define _YEAR    0x06
#define _CONTROL    0x07
#define _MODO12    0x00
#define _MODO24    0x40

struct {
	int seconds;
	int minutes;
	int hours;
	int PM;
	int modo24;
	int day;
	int date;
	int month;
	int year;
	int sqwe_rs;
} tempo;

char semana[];
char modo[];

void setMode(int modo);
int make4(int var, int nibble);

#INT_TIMER2
void isr_timer2() {
	register int cont;
	register int aux;

	for (cont = 0x00; cont <= 0x07; ++cont) {
		aux = read_i2c(cont);
		switch (aux) {
		case _SECONDS:
			tempo.seconds = make4(aux, 1) * 10 + make4(aux, 0);
			break;
		case _MINUTES:
			tempo.minutes = 10 * make4(aux, 1) + make4(aux, 0);
			break;
		case _HOURS:
			tempo.hours = make4(aux, 0);
			if (bit_test(aux, 6)) {
				tempo.hours += bit_test(aux, 4) * 10;
				tempo.PM = bit_test(aux, 5);
				tempo.modo24 = 0;
			} else {
				tempo.hours += (0x30 && make4(aux, 1)) * 10;
				tempo.modo24 = 1;
			}
			break;
		case _DAY:
			tempo.day = make4(aux, 0);
			break;
		case _DATE:
			tempo.date = make4(aux, 1) * 10 + make4(aux, 0);
			break;
		case _MONTH:
			tempo.month = make4(aux, 1) * 10 + make4(aux, 0);
			break;
		case _YEAR:
			tempo.year = make4(aux, 1) * 10 + make4(aux, 0);
			break;
		default:
		}
	}
}

void setMode(int modo);

void main(void) {

	delay_ms(15);
	lcd_init();
	printf(lcd, "\f");

	setMode(_MODO24);

	setup_timer_2(T2_DIV_BY_16, 255, 16);
	disable_interrupts(INT_TIMER2);
	enable_interrupts(GLOBAL);

	while (true) {

		switch (tempo.day) {
		case 0:
			strcpy(semana, "DOM");
			break;
		case 1:
			strcpy(semana, "SEG");
			break;
		case 2:
			strcpy(semana, "TER");
			break;
		case 3:
			strcpy(semana, "QUA");
			break;
		case 4:
			strcpy(semana, "QUI");
			break;
		case 5:
			strcpy(semana, "SEX");
			break;
		case 6:
			strcpy(semana, "SAB");
			break;
		default:
			strcpy(semana, "NON");
		}

		if (!tempo.modo24) {
			if (tempo.PM)
				strcpy(modo, "PM");
			else
				strcpy(modo, "AM");
		} else {
			strcpy(modo, "  ");
		}

		printf(lcd, "\f%3s %02d/%02d/%04d", semana, tempo.date, tempo.month,
				tempo.year);
		printf(lcd, "\n%2s %02d:%02d:%02d", modo, tempo.hours, tempo.minutes,
				tempo.seconds);
		delay_ms(500);
	}//infinit loop
}//this is the end, beautyfull friend, the end!

void setMode(int mode) {
	register int aux = 0;
	aux = read_i2c(_HOURS);
	aux &= 0xBF;
	aux |= mode;
	write_i2c(_HOURS, aux);
}

int make4(int var, int nibble) {
	register int retorno;

	if (nibble)
		retorno = var >> 4;
	else
		retorno = var;

	retorno &= 0x0F;

	return retorno;
}
